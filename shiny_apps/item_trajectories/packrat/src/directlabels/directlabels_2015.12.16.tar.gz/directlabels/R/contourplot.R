### Positioning Method for the top of a group of points.
top.pieces <- label.pieces(which.max,0)

### Positioning Method for the bottom of a group of points.
bottom.pieces <- label.pieces(which.min,1)
