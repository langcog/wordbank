context("C++")
expect_cpp_tests_pass("%s")
