#!/usr/bin/env perl

print "Status: 404\n",
      "Content-Type: text/plain\n",
      "\n",
      "send404\n";
