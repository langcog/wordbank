<?php
	header("Status: 404");

	print $_SERVER["PHP_SELF"];
?>
